#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "serial.h"

	int num_x;
	int num_y;
	int change_x;
	int change_xa;
    int px_n;
	int change_y;
	int change_ya;
	int py_n;
	int x_0= 118 ;
	int y_0= 113;
	int out_x=84;
	int out_y=85;
	int dx_n;
    int dy_n;
	int ix_n;
	int ix_nm=550;
	int iy_n;
	int iy_nm=550;
	int i , j , k ;
void pid_x()
{
		change_x = (num_x-x_0)*100;            //PID_X
        px_n = change_x * 0.7;          //P
		
		ix_n = ix_n + change_x*0.1;		//I
		if (ix_n>ix_nm)
		{
		ix_n = ix_nm;
		}
		if(ix_n<-ix_nm)
		{
		ix_n = -ix_nm;
		}
		dx_n =(change_x-change_xa)*9; //0.2 * changex_tD
		change_xa = change_x;
		out_x =(px_n+dx_n+ix_n)*90/16000+85;
}
	
void pid_y()
{
		change_y = (num_y-y_0)*100;            //PID_Y	
		py_n = change_y*0.7;			//P
	
	
		iy_n = iy_n + change_y* 0.1;		//I
		if (iy_n>iy_nm)
		{
		iy_n = iy_nm;
		}
		if(iy_n<-iy_nm)
		{
		iy_n = -iy_nm;
		}
		dy_n = (change_y-change_ya)*9;//D
		change_ya = change_y;
		out_y = (py_n+dy_n+iy_n)*90/12000+84;
}
void balance ()
{
		Serial_hex_x();
		Serial_hex_y();
		if (Serial_GetRxFlag_x() ==1)  //��ȡx��RX��������
		{
		Serial_SendByte_x(Serial_RxPacket_x[0]);
		Serial_SendByte_x(Serial_RxPacket_x[1]);
		Serial_SendByte_x(Serial_RxPacket_x[2]);
		num_x=(Serial_RxPacket_x[0]-48)*100+(Serial_RxPacket_x[1]-48)*10+(Serial_RxPacket_x[2]-48);
		pid_x();
		}
//		if(out_x < 20)                 //�������X
//		{
//		Servo_SetAngle1(160);
//		}
//		else if(out_x > 160)
//		{
//		Servo_SetAngle1(20);
//		}
//		else if(out_x>=20 && out_x<=160)
//		{
		Servo_SetAngle1(180-out_x);
//		}

		
		if (Serial_GetRxFlag_y() ==1)  //��ȡy��RX��������
		{
		Serial_SendByte_y(Serial_RxPacket_y[0]);
		Serial_SendByte_y(Serial_RxPacket_y[1]);
		Serial_SendByte_y(Serial_RxPacket_y[2]);
		num_y=(Serial_RxPacket_y[0]-48)*100+(Serial_RxPacket_y[1]-48)*10+(Serial_RxPacket_y[2]-48);
		pid_y();

		}
		
//		if(out_y<20)					//�������Y
//		{
//		Servo_SetAngle2(20);
//		}
//		else if(out_y>160)					
//		{
//		Servo_SetAngle2(160);
//		}
//		else if(out_y>=20 && out_y<=160)					
//		{
		Servo_SetAngle2(out_y);
//		}
		

}

void balance_1(void)
{
x_0 = 5;
y_0 = 186;
}

void balance_2(void)
{
x_0 = 122;
y_0 = 179;
}

void balance_3(void)
{
x_0 = 240;
y_0 = 168;
}

void balance_4(void)
{
x_0 = 5;
y_0 = 123;
}

void balance_5(void)
{
x_0 = 121;
y_0 = 112;
}

void balance_6(void)
{
x_0 = 255;
y_0 = 92;
}

void balance_7(void)
{
x_0 = 15;
y_0 = 74;
}

void balance_8(void)
{
x_0 = 123;
y_0 = 45;
}

void balance_9(void)
{
x_0 = 245;
y_0 = 40;	
}

void balance_10(void)
{
x_0 = 60;
y_0 = 140;	
}
void balance_11(void)
{
x_0 = 180;
y_0 = 150;	
}
void balance_12(void)
{
x_0 = 70;
y_0 = 90;	
}
void balance_13(void)
{
x_0 = 195;
y_0 = 70;	
}


void balance_20(void)
{
	balance_1();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_4();
	for(i=0;i<5;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_5();
	while(1)
	{
	balance ();
	}
}

void balance_21(void)
{
	balance_1();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_10();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_12();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_13();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_9();
	while(1)
	{
	balance ();
	}
}

void balance_22(void)
{
	balance_1();
	for(i=0;i<2;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_2();
	for(i=0;i<3;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_6();
	for(i=0;i<3;i++)
	{
		for(j=0;j<10000;j++)
		{
		balance ();
		Delay_us(100);
		}
	}
	balance_9();
	while(1)
	{
	balance();
	}
}

void balance_24(void)
{
		balance_4();
		for(i=0;i<2;i++)
		{
			for(j=0;j<10000;j++)
			{
			balance ();
			Delay_us(100);
			}
		}
		for(k=0;k<3;k++)
		{
			balance_10();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_11();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_13();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_12();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
		}
			balance_10();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_11();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_13();
			for(i=0;i<1;i++)
			{
				for(j=0;j<10000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_9();
			while(1)
			{
			balance();
			}
}

void balance_25(void)
{
	    balance_4();
		for(i=0;i<3;i++)
		{
			for(j=0;j<10000;j++)
			{
			balance ();
			Delay_us(100);
			}
		}
	while(1)
	{
			balance_10();
			for(i=0;i<1;i++)
			{
				for(j=0;j<7000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_11();
			for(i=0;i<1;i++)
			{
				for(j=0;j<7000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_13();
			for(i=0;i<1;i++)
			{
				for(j=0;j<7000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
			balance_12();
			for(i=0;i<1;i++)
			{
				for(j=0;j<7000;j++)
				{
				balance ();
				Delay_us(100);
				}
			}
	}
}
void balance_23(void)
{
	while(1)
	{
				balance_4();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
				
				balance_2();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
				
				balance_5();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
				
				balance_8();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
				
				balance_6();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
				balance_5();
				for(j=0;j<6000;j++)
				{
				balance ();
				Delay_us(100);
				}
	}
}



void balance_17(int signal1 , int signal2 ,int signal3,int signal4)
{
	while(1)
	{
		switch(signal1)
		{
		case 1 :  balance_1(); break;
		case 2 :  balance_2(); break;
		case 3 :  balance_3(); break;
		case 4 :  balance_4(); break;
		case 5 :  balance_5(); break;
		case 6 :  balance_6(); break;
		case 7 :  balance_7(); break;
		case 8 :  balance_8(); break;
		case 9 :  balance_9(); break;
		}
		for(i=0 ; i<1 ;i++)
		{
			for(j=0 ; j<15000 ; j++)
			{
			balance();
			Delay_us(100);
			}
		}
			switch(signal2)
		{
		case 1 :  balance_1(); break;
		case 2 :  balance_2(); break;
		case 3 :  balance_3(); break;
		case 4 :  balance_4(); break;
		case 5 :  balance_5(); break;
		case 6 :  balance_6(); break;
		case 7 :  balance_7(); break;
		case 8 :  balance_8(); break;
		case 9 :  balance_9(); break;
		}
		for(i=0 ; i<1 ;i++)
		{
			for(j=0 ; j<15000 ; j++)
			{
			balance();
			Delay_us(100);
			}
		}
			switch(signal3)
		{
		case 1 :  balance_1(); break;
		case 2 :  balance_2(); break;
		case 3 :  balance_3(); break;
		case 4 :  balance_4(); break;
		case 5 :  balance_5(); break;
		case 6 :  balance_6(); break;
		case 7 :  balance_7(); break;
		case 8 :  balance_8(); break;
		case 9 :  balance_9(); break;
		}
		for(i=0 ; i<1 ;i++)
		{
			for(j=0 ; j<15000 ; j++)
			{
			balance();
			Delay_us(100);
			}
		}
		switch(signal4)
		{
		case 1 :  balance_1(); break;
		case 2 :  balance_2(); break;
		case 3 :  balance_3(); break;
		case 4 :  balance_4(); break;
		case 5 :  balance_5(); break;
		case 6 :  balance_6(); break;
		case 7 :  balance_7(); break;
		case 8 :  balance_8(); break;
		case 9 :  balance_9(); break;
		}
		for(i=0 ; i<1 ;i++)
		{
			for(j=0 ; j<15000 ; j++)
			{
			balance();
			Delay_us(100);
			}
		}
	}
}
