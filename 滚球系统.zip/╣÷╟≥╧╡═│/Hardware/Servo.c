#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}
float angle0_x;
float change1_x;
float angle0_y;
float change1_y;
void Servo_SetAngle1(float Angle)
{
	change1_x=Angle-angle0_x;
	if (change1_x<2 && change1_x>-2)
	{
	Angle = angle0_x;
	}
	angle0_x  = Angle;
	PWM_SetCompare1(Angle / 180 * 2000 + 500);
}
void Servo_SetAngle2(float Angle)
{
	change1_y=Angle-angle0_y;
	if (change1_y<2 && change1_y>-2)
	{
	Angle = angle0_y;
	}
	angle0_y  = Angle;
	PWM_SetCompare2(Angle / 180 * 2000 + 500);
}
