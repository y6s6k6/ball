#ifndef __MATRIXKEY_H
#define __MATRIXKEY_H
void key1_Init(void);
void key2_Init(void);
char KeyScan(void);

#endif
