#ifndef __BALANCE_H
#define __BALANCE_H

	void balance (void);
	void balance_1(void);
	void balance_2(void);
	void balance_3(void);
	void balance_4(void);
	void balance_5(void);
	void balance_6(void);
	void balance_7(void);
	void balance_8(void);
	void balance_9(void);
	void balance_10(void);
	void balance_11(void);
	void balance_12(void);			
	void balance_13(void);
	void balance_14(void);
	void balance_15(void);
	void balance_16(void);
	void balance_20(void);
	void balance_21(void);
	void balance_22(void);
	void balance_24(void);
	void balance_25(void);
	void balance_23(void);
	void balance_17(int signal1 , int signal2 ,int signal3,int signal4);
#endif
