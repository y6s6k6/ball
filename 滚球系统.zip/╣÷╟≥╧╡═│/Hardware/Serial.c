#include "stm32f10x.h"                  // Device header


uint8_t Serial_RxData;
uint8_t Serial_RxFlag_x;
uint8_t Serial_RxFlag_y;
uint8_t Serial_RxPacket_x[3];
uint8_t Serial_RxPacket_y[3];

void Serial_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin =GPIO_Pin_3 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
		
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	USART_Init(USART2, &USART_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
	USART_Cmd(USART2, ENABLE);
}

void Serial_SendByte_x(uint8_t Byte) //������x��TX���ڴ����ȥ
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void Serial_SendByte_y(uint8_t Byte) //������y��TX���ڴ����ȥ
{
	USART_SendData(USART2, Byte);
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}

uint8_t Serial_GetRxFlag_x(void)//(�ж�)
{
	if (Serial_RxFlag_x == 1)
	{
		Serial_RxFlag_x = 0;
		return 1;
	}
	return 0;
}

uint8_t Serial_GetRxFlag_y(void)//(�ж�)
{
	if (Serial_RxFlag_y == 1)
	{
		Serial_RxFlag_y = 0;
		return 1;
	}
	return 0;
}

//��ѯ��ʽ
void Serial_hex_x(void)//��ȡhex���ݰ�����ѯ��ʽ��
{
	static uint8_t RxState = 0;
	static uint8_t pRxPacket = 0;
	if (USART_GetFlagStatus(USART1 ,USART_FLAG_RXNE) == SET)  //�����hex��������ִ�����²���
	{
		uint8_t RxData;
		RxData = USART_ReceiveData(USART1);
		
			if (RxState == 0)
			{
				if (RxData == 0x46) 
				{
					RxState = 1;
					pRxPacket = 0;
				}
			}
			else if (RxState == 1)
			{
				Serial_RxPacket_x[pRxPacket] = RxData;
				pRxPacket ++;
				if (pRxPacket >= 3)
				{
					RxState = 2;
				}
			}
			else if (RxState == 2)
			{
				if (RxData == 0x45)
				{
					RxState = 0;
					Serial_RxFlag_x = 1;
//					Serial_SendPacket();
				}
			}
	    
	}
}
void Serial_hex_y(void)//��ȡhex���ݰ�����ѯ��ʽ��
{
	static uint8_t RxState = 0;
	static uint8_t pRxPacket = 0;
	if (USART_GetFlagStatus(USART2 ,USART_FLAG_RXNE) == SET)  //�����hex��������ִ�����²���
	{
		uint8_t RxData;
		RxData = USART_ReceiveData(USART2);
		
			if (RxState == 0)
			{
				if (RxData == 0x46) 
				{
					RxState = 1;
					pRxPacket = 0;
				}
			}
			else if (RxState == 1)
			{
				Serial_RxPacket_y[pRxPacket] = RxData;
				pRxPacket ++;
				if (pRxPacket >= 3)
				{
					RxState = 2;
				}
			}
			else if (RxState == 2)
			{
				if (RxData == 0x45)
				{
					RxState = 0;
					Serial_RxFlag_y = 1;
//					Serial_SendPacket();
				}
			}
	    
	}
}

