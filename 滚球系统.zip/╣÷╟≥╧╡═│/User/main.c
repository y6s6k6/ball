#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "serial.h"
#include "balance.h"
#include "key.h"

int x;
uint8_t keynum = 5 , keynum_0;
int bot1, bot2, bot3, bot4 , bot=1;

void setkey()
{
	if(keynum == 15)
	{	
	Delay_s(1);
			
	keynum = 0;
		while(1)
		{
			OLED_ShowNum(1,10,keynum,2);
			
			switch(bot)
			{
				case 1 : bot1 =keynum ; OLED_ShowNum(1,5,bot1,2) ;break;
				case 2 : bot2 =keynum ; OLED_ShowNum(2,5,bot2,2) ;break;
				case 3 : bot3 =keynum ; OLED_ShowNum(3,5,bot3,2) ;break;
				case 4 : bot4 =keynum ; OLED_ShowNum(4,5,bot4,2) ;break;
			}
			for(x=0;x<500;x++)
			{
			keynum = KeyScan();
			Delay_ms(1);
			OLED_ShowNum(1,8,keynum,2);
			}
			if(keynum == 15)
			{
			bot++;
			Delay_s(1);
			keynum = 0 ;OLED_ShowNum(1,12,keynum,2);
			}
			if(bot == 5)
			{
			
			keynum = 0;
			balance_17(bot1,bot2,bot3,bot4);
			}

		}
	}
}



void number()
{
	switch(keynum)
	{
		case 1: balance_1() ;keynum = 0;break;
		case 2: balance_2() ;keynum = 0;break;
		case 3: balance_3() ;keynum = 0;break;
		case 4: balance_4() ;keynum = 0;break;
		case 5: balance_5() ;keynum = 0;break;
		case 6: balance_6() ;keynum = 0;break;
		case 7: balance_7() ;keynum = 0;break;
		case 8: balance_8() ;keynum = 0;break;
		case 9: balance_9() ;keynum = 0;break;
		case 10: balance_20() ;keynum = 0;break;
		case 11: balance_21() ;keynum = 0;break;
		case 12: balance_22() ;keynum = 0;break;
		case 13: balance_24() ;keynum = 0;break;
		case 14: balance_25() ;keynum = 0;break;
//		case 15: balance_15() ;keynum = 0;break;
		case 16: balance_23() ;keynum = 0;break;
	}
	
}


int main(void)
{
	Servo_Init();	
	Serial_Init();
	OLED_Init();
	OLED_ShowString(1,1,"num1");
	OLED_ShowString(2,1,"num2");
	OLED_ShowString(3,1,"num3");
	OLED_ShowString(4,1,"num4");
	while (1)
	{
		balance ();
		keynum = KeyScan();
		number();
		setkey();
	}
}
